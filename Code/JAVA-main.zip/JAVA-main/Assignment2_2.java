import java.util.Scanner;

public class Assignment2_2 {
    public static void main(String[] args) {
     try (Scanner input = new Scanner(System.in)) {
        System.out.println("Enter the name");
         String name=input.next();
        // char ch=input.next().trim().charAt((06));
            System.out.println("Hey  " +name + "  Good morning");
    }
    }
    
}
