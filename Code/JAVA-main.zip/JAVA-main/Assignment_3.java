public class Assignment_3 {
    public static void main(String[] args) {
        int num=5;
        int multiple=1;
        while (multiple<11) {
          int a=  num *multiple;
          multiple++;
          System.out.println(a);
        }
    }
}
