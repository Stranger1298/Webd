import java.util.Scanner;

public class Assignment_5 {
    public static void main(String[] args) {
        try (Scanner input = new Scanner(System.in)) {
            System.out.println("Enter the numbers");
           // int num=input.nextInt();
           // int sum=0;
            if (input.nextInt() !='x' || input.nextInt() !='X') {
                //  sum=input+sum;
            }
            else {
                System.out.println("Their sum is:");
            }
        }
       


    }
}
