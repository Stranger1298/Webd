import java.util.Scanner;

public class Functions {

    public static void Print_Name(String strings) {
        return;
    }
    public static void main(String[] args) {
        Scanner input=new Scanner(System.in);
        String strings=input.next();
        System.out.println(strings);//calling function
    //    Print_Name(strings);//calling function
    
    }
}
