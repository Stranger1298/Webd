public class First{
     
    public static void main(String[] args) {
/* 
      int Salary = 5000;
      if (Salary > 5000) {
        Salary = Salary + 2000;
      }
      else {
        Salary = Salary + 1000;
      }
      System.out.println( Salary);
      */

      //print no. from 1 to 20 alternatively

        for (int num = 1 ; num < 20 ;num +=2){
         System.out.println(num);
     }
       System.out.println("code end");
    }
    }
    

